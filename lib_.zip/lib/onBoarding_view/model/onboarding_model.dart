class OnBoardingModel{
  String img;
  String description;
  OnBoardingModel({required this.img,required this.description});
}