import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:meal/navigation/pages.dart';
import 'package:meal/navigation/routes.dart';
import 'package:meal/onBoarding_view/model/onboarding_model.dart';

class OnBoardingController extends GetxController {
  List<OnBoardingModel> onBoardItem = <OnBoardingModel>[];
  final pageViewController = PageController(
    viewportFraction: 1.0,
  );

  var page = 0.obs;

  @override
  void onInit() {
    onBoardItem.add(OnBoardingModel(img: "assets/images/A.jpg", description: "Hello"),);
    onBoardItem.add(OnBoardingModel(img: "assets/images/A.jpg", description: "Hi"),);
    onBoardItem.add(OnBoardingModel(img: "assets/images/A.jpg", description: "how's"),);
    onBoardItem.add(OnBoardingModel(img: "assets/images/A.jpg", description: "you"),);
    super.onInit();
  }

  void nextPage() {
    if (page.value == 3) {
         Get.offAllNamed(Pages.loginView);
        } else {
      page.value=page.value+1;
      pageViewController.animateToPage(page.value.toInt(),
          duration: const Duration(milliseconds: 300), curve: Curves.linear);
    }
  }
}
