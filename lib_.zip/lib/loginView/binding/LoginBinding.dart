import 'package:get/get.dart';
import 'package:meal/loginView/controller/Controller.dart';

class LoginBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => LoginController());
    // TODO: implement dependencies
  }

}