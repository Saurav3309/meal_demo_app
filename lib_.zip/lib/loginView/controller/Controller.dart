import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class LoginController extends GetxController{
  var emailController=TextEditingController();
  var passwordController=TextEditingController();
  RxBool visible=false.obs ;

  void loginCondition() {
    if(emailController.text.isNotEmpty && passwordController.text.isNotEmpty){
      FirebaseAuth.instance.signInWithEmailAndPassword(email: emailController.text.trim(), password: passwordController.text.trim()).then((value) {
        if(value!=''){
          print("loginSucess");
        }
      }).catchError((onError){
        print("loginFail");
      });
      
      
      // if(emailController.text.toLowerCase()=='Saurav@gmail.com'.toLowerCase() && passwordController.text=='12345678'){
      //   print('ok');
      //   // Fluttertoast.showToast(msg: 'verified',toastLength: Toast.LENGTH_SHORT);
      // }else{
      //   print('fail');
      //   // Fluttertoast.showToast(msg: 'mismatched',toastLength: Toast.LENGTH_SHORT);
      // }
    }else{
      print('required');

      // Fluttertoast.showToast(msg: 'Email and Password is required',toastLength: Toast.LENGTH_SHORT);
    }
  }

  void passwordVisible(){
    visible.value=!visible.value;
  }

}