import 'package:get/get.dart';
import 'package:meal/loginView/LoginVIew.dart';
import 'package:meal/navigation/pages.dart';
import 'package:meal/onBoarding_view/binding/onbording_binding.dart';
import 'package:meal/onBoarding_view/view/onboarding_view.dart';
import 'package:meal/register/RegisterView.dart';
import 'package:meal/register/binding/register_view.dart';
import 'package:meal/splash/splash.dart';

import '../loginView/binding/LoginBinding.dart';

class Routes{

  static final routes=[
  GetPage(name: Pages.splash, page: ()=> SplashView()),
  GetPage(name: Pages.onBoardingView, page: ()=> OnBoardingView(),binding:OnBoardBinding()),
  GetPage(name: Pages.loginView, page: ()=> LoginView(),binding:LoginBinding()),
  GetPage(name: Pages.registerView, page: ()=> RegisterView(),binding:RegisterBinding()),

  ];


}