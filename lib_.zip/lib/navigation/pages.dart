class Pages{
  static const String splash='/splash';

  static const String onBoardingView='/onBoarding';
  static const String loginView='/loginView';
  static const String registerView='/registerView';
}