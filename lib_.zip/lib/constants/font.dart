class Fonts{
  static const String semiBold="Laila-SemiBold";
  static const String bold="Laila-Bold";
  static const String light="Laila-Light";
  static const String medium="Laila-Medium";
  static const String regular="Laila-Regular";
}