import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class RegisterController extends GetxController {
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();
  var nameController = TextEditingController();
  var firebaseAuth = FirebaseAuth.instance;

  void registerUser() {
    if (passwordController.text != confirmPasswordController.text) {
      print("password mismatch");
      return;
    }
    firebaseAuth.createUserWithEmailAndPassword(
      email: emailController.text.trim(),
      password: confirmPasswordController.text.trim(),).then((value) {
      print("sucess");
    }).catchError((onError) {
      print("fail");
    });
  }
}
